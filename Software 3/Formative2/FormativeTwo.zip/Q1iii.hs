module Q1iii where -- 2 marks
import Q1i 
import Q1ii

{-
Initially all of a player's pieces are at the `Start` position,
waiting to enter the board.  The first move is by the red player.


Implement the initial game state, `initGS`.
-}
initGS :: GameState
initGS = undefined
