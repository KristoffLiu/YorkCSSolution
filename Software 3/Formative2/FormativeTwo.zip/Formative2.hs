module Formative2 where
import Q1i 
import Q1ii
import Q1iii 
import Q1iv 
import Q1v
import Q1vi
import Q1vii

