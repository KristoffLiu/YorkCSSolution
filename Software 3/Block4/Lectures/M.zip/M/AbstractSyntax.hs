module M.AbstractSyntax where
import Data.Array

type M = Array Int Instr -- a program is an array of instructions

mkM :: [Instr] -> M
mkM js = listArray (0, length js - 1) js

newtype R = R String deriving (Eq, Ord, Show) -- register names
newtype L = L String deriving (Eq, Ord, Show) -- label names
newtype I = I Int    deriving (Eq, Ord, Show) -- `immediate' data

data Instr =
  -- below:
  -- pc is the register representing the program counter
  -- t is a target register;
  -- r, s are source registers;
  -- n is an immediate integer.
  -- u^ is the value stored in register u
  -- l* is the address (line number) of label l
  -- Instruction names include the types of any source parameters
  -- Miscellaneous
    Label L     -- labels to be the target of a jump
  | NoOp        -- pc := pc+1
  | PrintR R    -- print value in r; pc := pc+1
  -- Arithmetic instructions
  | MovR R R    -- t := r^; pc := pc+1
  | MovI R I    -- t := n; pc := pc+1
  | AddRR R R R -- t := r^ + s^; pc := pc+1
  | AddRI R R I -- t := r^ + n; pc := pc+1
  | MulRR R R R -- t := r^ * s^; pc := pc+1
  | MulRI R R I -- t := r^ * n; pc := pc+1
  | NegR R R    -- t := -r^; pc := pc+1
  -- Program counter manipulation
  | Halt        -- pc := Nothing
  | JumpL L     -- pc := l*
  | JumpR R     -- pc := r^
  -- Conditional program counter manipulation
  | BeqRR L R R -- pc := if r^=s^  then l* else pc+1
  | BeqRI L R I -- pc := if r^=n   then l* else pc+1
  | BneRR L R R -- pc := if r^!=s^ then l* else pc+1
  | BneRI L R I -- pc := if r^!=n  then l* else pc+1
  | BltRR L R R -- pc := if r^<s^  then l* else pc+1
  | BltRI L R I -- pc := if r^<n   then l* else pc+1
  | BgeRR L R R -- pc := if r^>=s^ then l* else pc+1
  | BgeRI L R I -- pc := if r^>=n  then l* else pc+1
  -- Address manipulation instructions
  | MovL R L    -- t := l*
  -- external store manipulation; a& is the external location at address a 
  | LoadR R R   -- t := ((r^)&)^
  | LoadI R I   -- t := (n&)^
  | StoreR R R  -- (t^)& := r^
  | StoreI I R  -- n& := r^
  deriving (Eq, Show)

-- A jumptable tells us where to jump when decoding a label
jumptable :: M -> L -> Int
jumptable js l = head [n | (n, Label l') <- assocs js, l==l']

prettyprint :: M -> String
prettyprint    js = unlines (format <$> assocs js)
  where
    format (n, i) = spaces (5 - length sn) ++ sn ++ ". " ++ fmt (ins i)
      where
        sn = show n
        fmt ["Label", l] = l ++ ":"
        fmt (s:ss) = unwords ("        ": pad 7 s: (pad 4 <$> ss))
        spaces = flip replicate ' '
        pad n s = s ++ spaces ((n - length s) `max` 1)

{-
  NOTE: 'ins' is a prime candidate for creation using
  the "Template Haskell" extension. See:
    http://wiki.haskell.org/Template_Haskell
  Template Haskell is beyond the scope of SOF3, so this is in long-hand.
-}
ins :: Instr                     -> [String]
ins    (Label  (L l))             = ["Label", l]
ins    NoOp                       = ["NoOp"]
ins    (PrintR (R r))             = ["PrintR", r]
ins    (MovR   (R t) (R r))       = ["MovR", t, r]
ins    (MovI   (R t) (I n))       = ["MovI", t, show n]
ins    (AddRR  (R t) (R r) (R s)) = ["AddRR", t, r, s]
ins    (AddRI  (R t) (R r) (I n)) = ["AddRI", t, r, show n]
ins    (MulRR  (R t) (R r) (R s)) = ["MulRR", t, r, s]
ins    (MulRI  (R t) (R r) (I n)) = ["MulRI", t, r, show n]
ins    (NegR   (R t) (R r))       = ["Neg", t, r]
ins    Halt                       = ["Halt"]
ins    (JumpL  (L l))             = ["JumpL", l]
ins    (JumpR  (R r))             = ["JumpR", r]
ins    (BeqRR  (L l) (R r) (R s)) = ["BeqRR", l, r, s]
ins    (BeqRI  (L l) (R r) (I n)) = ["BeqRI", l, r, show n]
ins    (BneRR  (L l) (R r) (R s)) = ["BneRR", l, r, s]
ins    (BneRI  (L l) (R r) (I n)) = ["BneRI", l, r, show n]
ins    (BltRR  (L l) (R r) (R s)) = ["BltRR", l, r, s]
ins    (BltRI  (L l) (R r) (I n)) = ["BltRI", l, r, show n]
ins    (BgeRR  (L l) (R r) (R s)) = ["BgeRR", l, r, s]
ins    (BgeRI  (L l) (R r) (I n)) = ["BgeRI", l, r, show n]
ins    (MovL (R r) (L l))         = ["MovL", r, l]
ins    (LoadR  (R t) (R r))       = ["LoadR", t, r]
ins    (LoadI  (R t) (I n))       = ["LoadI", t, show n]
ins    (StoreR (R t) (R r))       = ["StoreR", t, r]
ins    (StoreI (I n) (R r))       = ["StoreI", show n, r]
