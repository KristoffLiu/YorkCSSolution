module M.RegisterAllocation (allocateRegisters) where

import M.AbstractSyntax
import M.Optimiser (liveOut, use, def)
import Data.Array as A
import Data.Set as S
import Data.Map.Strict as MS

{-
n is the number of available registers; machine registers are named R0..R(n-1).
Also have T0, T1, T2 as temporary registers for spilling: none of these may be used in original program.
-}
type RegInfo a = Map R a -- structure to store informatin of type `a' for some registers
data Colour = Reg Int | Mem Int | ST deriving (Eq, Ord) -- a colour is either a machine register or a neutral memory location or the special ST (StackTop)
type Allocation = RegInfo Colour -- a!r==Just k means Rk is allocated to r; a!r==Nothing means r must be spilt
type Graph = RegInfo (Set R) -- adjacency lists representation of an undirected, unweighted graph

mkR :: Int -> R
mkR = R . ('R':) . show
rT, rR, rS :: R
rT = R "T0"
rR = R "T1"
rS = R "T2"
stackTop = R "_StackTop"
rST = R "S"
strT, ldR, ldS :: Int -> Instr
strT = flip StoreI rT . I
ldR  = LoadI rR . I
ldS  = LoadI rS . I

allocateRegisters :: Int -> M -> M -- n is the number of registers to allocate
allocateRegisters    n      js = mkM (concat (update <$> js))
  where
    allocation = fmap ((MS.!) (colour n (interferenceGraph js)))
    update :: Instr -> [Instr]
    update (PrintR r)    = targetlessR PrintR [r]
    update (MovR t r)    = oneOpR MovR [t, r]
    update (MovI t n)    = storeOne (flip MovI n) [t]
    update (AddRR t r s) = arithOpRR AddRR [t, r, s]
    update (AddRI t r n) = arithOpRI AddRI [t, r] n
    update (MulRR t r s) = arithOpRR MulRR [t, r, s]
    update (MulRI t r n) = arithOpRI MulRI [t, r] n
    update (NegR t r)    = oneOpR NegR [t, r]
    update (JumpR r)     = targetlessR JumpR [r]
    update (BeqRR l r s) = branchRR (BeqRR l) [r, s]
    update (BeqRI l r m) = branchRI (flip (BeqRI l) m) [r]
    update (BneRR l r s) = branchRR (BneRR l) [r, s]
    update (BneRI l r m) = branchRI (flip (BneRI l) m) [r]
    update (BltRR l r s) = branchRR (BltRR l) [r, s]
    update (BltRI l r m) = branchRI (flip (BltRI l) m) [r]
    update (BgeRR l r s) = branchRR (BgeRR l) [r, s]
    update (BgeRI l r m) = branchRI (flip (BgeRI l) m) [r]
    update (MovL t l)    = storeOne (flip MovL l) [t]
    update (LoadR t r)   = oneOpR LoadR [t, r] 
    update (LoadI t n)   = case allocation [t] of
                             [Reg k] -> [LoadI (mkR k) n] -- should not be any other cases
                             _       -> error "Oooops: LoadI register allocation"
    update (StoreR t r)  = oneOpR StoreR [t, r]
    update (StoreI n t)  = case allocation [t] of
                             [Reg k] -> [StoreI n (mkR k)]
                             _       -> error "Ooooops: StoreI register allocation"
    update i             = [i] -- all other instructions

    targetlessR instr rs = case allocation rs of
                             [ST]    -> [instr rST]
                             [Reg k] -> [instr (mkR k)]
                             [Mem k] -> [ldR k, instr rR]
    oneOpR instr rs = case allocation rs of
                        [ST, Reg l]    -> [instr rST (mkR l)]
                        [Reg k, ST]    -> [instr (mkR k) rST]
                        [Reg k, Reg l] -> [instr (mkR k) (mkR l)]
                        [Reg k, Mem l] -> [ldR l, instr (mkR k) rR]
                        [Mem k, Reg l] -> [instr rT (mkR l), strT k]
                        [Mem k, Mem l] -> [ldR l, instr rT rR, strT k]
    storeOne instr_p rs = case allocation rs of
                            [ST]    -> [instr_p rST]
                            [Reg k] -> [instr_p (mkR k)]
                            [Mem k] -> [instr_p rT, strT k]
    arithOpRR instr rs = case allocation rs of
                           [Reg k, Reg l, Reg m] -> [instr (mkR k) (mkR l) (mkR m)]
                           [Reg k, Reg l, Mem m] -> [ldS m, instr (mkR k) (mkR l) rS]
                           [Reg k, Mem l, Reg m] -> [ldR l, instr (mkR k) rR (mkR m)]
                           [Mem k, Reg l, Reg m] -> [instr rT (mkR l) (mkR m), strT k]
                           [Reg k, Mem l, Mem m] -> [ldR l, ldS m, instr (mkR k) rR rS]
                           [Mem k, Reg l, Mem m] -> [ldS m, instr rT (mkR l) rS, strT k]
                           [Mem k, Mem l, Reg m] -> [ldR l, instr rT rR (mkR m), strT k]
    arithOpRI instr rs n = case allocation rs of
                             [ST, ST]       -> [instr rST rST n]
                             [Reg k, Reg l] -> [instr (mkR k) (mkR l) n]
                             [Reg k, Mem l] -> [ldR l, instr (mkR k) rR n]
                             [Mem k, Reg l] -> [instr rT (mkR l) n, strT k]
                             [Mem k, Mem l] -> [ldR l, instr rT rR n, strT k]
    branchRR instr_l rs = case allocation rs of
                             [Reg l, Reg m] -> [instr_l (mkR l) (mkR m)]
                             [Reg l, Mem m] -> [ldS m, instr_l (mkR l) rS]
                             [Mem l, Reg m] -> [ldR l, instr_l rR (mkR m)]
                             [Mem l, Mem m] -> [ldR l, ldS m, instr_l rR rS]
    branchRI instr_lm rs = case allocation rs of
                             [Reg k] -> [instr_lm (mkR k)]
                             [Mem k] -> [ldR k, instr_lm rR]

interferenceGraph :: M -> Graph
interferenceGraph    js = MS.fromList [(r, S.fromList [s | s <- registers, r `interfere` s]) | r <- registers]
  where
    registers = S.toList (S.unions (regInInstr <$> indices js))
      where regInInstr j = let lookUpj f = (A.!) (f js) j in S.delete stackTop (lookUpj def `S.union` lookUpj use)
    r `interfere` s = r/=s && or [S.insert r (S.singleton s) `isSubsetOf` lis | lis <- liveIn]
    liveIn = [((A.!) (use js) n) `S.union` (((A.!) (liveOut js) n) `S.difference` ((A.!) (def js) n)) | n <- indices js] -- liveIn is a dual to liveOut

colour :: Int -> Graph -> Allocation -- a version of Chaitlin's graph-colouring algorithm.
colour    n    = MS.insert stackTop ST . colour_n 0
  where
    colour_n location g | MS.null g = MS.empty
                        | otherwise = MS.insert chosenSymbolicReg chosenColour allocationLess_chosenSymbolicReg
      where
        chosenSymbolicReg = snd(minimum [(S.size ((MS.!) g s), s) | s <- keys g])
        allocationLess_chosenSymbolicReg = colour_n (update_loc location) (S.delete chosenSymbolicReg <$> MS.delete chosenSymbolicReg g)
        availableRealReg = [k | k <- Reg <$> [0..n-1], not (k `elem` (((MS.!) allocationLess_chosenSymbolicReg) <$> S.toList ((MS.!) g chosenSymbolicReg)))]
        chosenColour | availableRealReg==[]   = Mem location
                     | otherwise              = minimum availableRealReg
        update_loc | Mem _ <- chosenColour = succ
                   | otherwise             = id
