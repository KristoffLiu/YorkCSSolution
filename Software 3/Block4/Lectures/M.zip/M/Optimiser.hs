module M.Optimiser (optimise, liveOut, def, use) where

{-

This module implements a two-part optimisation:
* Value propagation, for which we need to analyse reachability of locations from assignments; and
* Dead-code elimination, for which we need to analyse liveness of values in registers.

The two analyses are duals of each other, and can be implemented taking advantage of laziness.
Both produce an infinite sequence of better an better approximations to the reachability or liveness graph (as appropriate).
The answer in both cases is found by looking finitely along the infinite list until the approximation stabilises to a fixed value.

Inputs to the algorithm are:
* the control flow graph or its reverse
* two types of property of instructions (gen & kill sets or use & def sets) 

-}

import M.AbstractSyntax
import Data.Set as S -- for gen, kill, use & def sets
import Data.Array as A

successor, predecessor :: M -> Array Int (Set Int)
successor js = listArray (bounds js) (f <$> assocs js)
  where
    gl l   = singleton (jumptable js l)
    br n l = (n+1) `S.insert`  (gl l)
    f (_, Halt)        = empty
    f (_, JumpL l)     = gl l
    f (_, JumpR _)     = S.fromAscList (indices js)
    f (n, BeqRR l _ _) = br n l
    f (n, BeqRI l _ _) = br n l
    f (n, BneRR l _ _) = br n l
    f (n, BneRI l _ _) = br n l
    f (n, BltRR l _ _) = br n l
    f (n, BltRI l _ _) = br n l
    f (n, BgeRR l _ _) = br n l
    f (n, BgeRI l _ _) = br n l
    f (n, _)           = singleton (n+1) -- all other instructions

predecessor js = accumArray union empty (bounds js) (concat [f x <$> toList (successor js ! x) | x <- indices js])
  where
    f x y = (y, singleton x)

-- utility functions
trgt, used :: Instr -> Set R
--
trgt (MovR t _)    = singleton t
trgt (MovI t _)    = singleton t
trgt (AddRR t _ _) = singleton t
trgt (AddRI t _ _) = singleton t
trgt (MulRR t _ _) = singleton t
trgt (MulRI t _ _) = singleton t
trgt (NegR t _)    = singleton t
trgt (MovL t _)    = singleton t
trgt (LoadR t _)   = singleton t
trgt (LoadI t _)   = singleton t
trgt _             = empty -- all others
--
used (PrintR r)    = singleton r
used (MovR _ r)    = singleton r
used (AddRR _ r s) = fromList [r, s]
used (AddRI _ r _) = singleton r
used (MulRR _ r s) = fromList [r, s]
used (MulRI _ r _) = singleton r
used (NegR _ r)    = singleton r
used (JumpR r)     = singleton r
used (BeqRR _ r s) = fromList [r, s]
used (BeqRI _ r _) = singleton r
used (BneRR _ r s) = fromList [r, s]
used (BneRI _ r _) = singleton r
used (BltRR _ r s) = fromList [r, s]
used (BltRI _ r _) = singleton r
used (BgeRR _ r s) = fromList [r, s]
used (BgeRI _ r _) = singleton r
used (LoadR _ r)   = singleton r
used (StoreR t r)  = fromList [t, r]
used (StoreI _ r)  = singleton r
used _             = empty -- all others
--

-- Functions for reachability analysis
gen, kill :: M -> Array Int (Set Int)
gen          js = listArray (bounds js) [if S.null (trgt i) then empty else singleton n | (n, i) <- assocs js]
kill         js = array (bounds js) [(m, result (tjs m) m) | m <- ijs]
  where ijs = indices js
        tjs = trgt . (js!)
        result tm m = if S.null tm then empty else fromList [n | n <- ijs, n/=m, tjs n == tm]

-- Functions for liveness analysis
def, use :: M -> Array Int (Set R)
def      = (trgt <$>)
use      = (used <$>)

-- initial approximation
approxZero :: M -> Array Int (Set a)
approxZero    js = accumArray (flip const) empty (bounds js) []

-- next approximation function
approxNtoNplusOne :: Ord a => (Array Int (Set Int)) -> Array Int (Set a) -> Array Int (Set a) -> (Int -> Int -> Bool) -> Array Int (Set a) -> Array Int (Set a)
approxNtoNplusOne graph plus minus comp approx
  = approx'
  where
    approx' = array (bounds graph) [(n, unions ((fromList . ((upd n)<$>) . toList . (graph!)) n)) | n <- indices graph]
    upd n m = (plus ! m) `union` ((if m `comp` n then approx' else approx) ! m `difference` (minus ! m))

-- fixed point finder: relies on laziness
--                 reachability/liveness
-- graph is one of predecessor /successor
-- plus  is one of gen         /use
-- minus is one of kill        /def
-- comp  is one of (<)         /(>)
findFixedPoint :: Ord a => M -> (M -> Array Int (Set a) -> Array Int (Set a)) -> Array Int (Set a)
findFixedPoint js step = head [x | (x, y) <- zip approxes (tail approxes), x==y]
  where approxes = iterate (step js) (approxZero js)

{-
"reachIn m n" gives the set of line numbers of assignments that reach in to Line n.
If any are the only assignment to a used register, and assignment of a constant,
there is an opportunity to propagate the constant to line n.
"MathOpRR t r s" with "MovI s k" being the sole s-assignment reaching in can be replaced by "MathOpRI t r k".
If "r" satisfies the same conditions, and MathOp is symmetric, it can be replaced by "MathOpRI t s k".
If both "r" and "s" satisfy the condition, wrt "MovI r k", "MovI s l", it can be replaced by "MovI t (k Op l)".

"liveOut m n" gives the registers whose current values at Line n may be used later.
If Line n is an assignment to a register that is not live out, the line may be deleted.
(If timings are important it may be necessary to replace it with a number of NoOp instructions.)
-}

reachInStep :: M -> Array Int (Set Int) -> Array Int (Set Int)
reachInStep    js = approxNtoNplusOne (predecessor js) (gen js) (kill js) (<)
reachIn :: M -> Array Int (Set Int)
reachIn =  flip findFixedPoint reachInStep
liveOutStep :: M -> Array Int (Set R) -> Array Int (Set R)
liveOutStep    js = approxNtoNplusOne (successor js) (use js) (def js) (>)
liveOut :: M -> Array Int (Set R)
liveOut = flip findFixedPoint liveOutStep

propagateLine :: M -> Int -> Instr
propagateLine    js   n    = update (js ! n)
  where
    update i =
      case i of
        MovR  t r   -> arone t r   i id
        AddRR t r s -> artwo t r s i (+) AddRI
        MulRR t r s -> artwo t r s i (*) MulRI
        NegR  t r   -> arone t r   i (\(I n)-> I (negate n))
        BeqRR l r s -> brnch l r s i (==) BeqRI BeqRI
        BneRR l r s -> brnch l r s i (/=) BneRI BneRI
        BltRR l r s -> brnch l r s i (<)  BgeRI BltRI
        BgeRR l r s -> brnch l r s i (>=) BltRI BgeRI
        _           -> i
    -----
    acn r | [MovI r k] <- [js ! l | l <- toList ((reachIn js) ! n), trgt (js ! l) == singleton r] = Just k
          | otherwise                                                                                            = Nothing
    iOp f (I j) (I k) = I (f j k)
    negI (I j)        = I (negate j)
    twoar i f g h jk = case jk of
                         (Just j, Just k) -> f j k
                         (Just j, _     ) -> g j
                         (_     , Just k) -> h k
                         _                -> i
    arone t r   i ao       = maybe i (MovI t . ao)                                              (acn r)
    artwo t r s i ao ii    = twoar i ((MovI t .) . iOp ao)                    (ii t s) (ii t r) (acn r, acn s)
    brnch l r s i eo aj bj = twoar i (\j k->if eo j k then JumpL l else NoOp) (aj l s) (bj l r) (acn r, acn s)

propagate :: M -> M
propagate    js = mkM (propagateLine js <$> indices js)

eliminateLine :: M -> Int -> Maybe Instr
eliminateLine js n 
  | trgt instr `isSubsetOf` ((liveOut js) ! n) = Just instr
  | otherwise                                  = Nothing
  where instr = js ! n

eliminate :: M -> M
eliminate    js = mkM [i | (Just i) <- eliminateLine js <$> indices js]

globalOptimise :: M -> M
globalOptimise =  eliminate . propagate


-------------------------------------------------
-- Local optimisations (peephole optimisations for a peephole of size 1)

killNoOp :: M -> M
killNoOp    js = mkM (Prelude.filter (/=NoOp) (A.elems js))

killOpUnit :: M -> M
killOpUnit =  (f<$>)
  where f (AddRI t r (I 0)) | t==r      = NoOp
                            | otherwise = MovR t r
        f (MulRI t r (I 1)) | t==r      = NoOp
                            | otherwise = MovR t r
        f i                 = i

localOptimise :: M -> M
localOptimise =  killNoOp . killOpUnit

optimise :: M -> M
optimise =  localOptimise . globalOptimise

