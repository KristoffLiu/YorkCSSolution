module M.Interpreter (interpret) where
{-
  A small step interpreter for M
-}
import M.AbstractSyntax
import Data.Array as A
import Data.Map.Strict as Map

{-
The register bank and main memory are modelled as strict maps.
The difference is the type of the key.
-}

type RegisterBank = Map R   Int
type MainMemory   = Map Int Int

getval :: Ord a => Map a Int -> a -> Int
getval mv = (maybe undefined id) . (flip Map.lookup mv)

{-
A state contains: the program counter, the register bank, the main memory, and the output buffer
-}
data State = State (Maybe Int) RegisterBank MainMemory String

halted :: State                -> Bool
halted    (State Nothing _ _ _) = True
halted     _                    = False

interpret :: M -> String
interpret js = ob
  where
    (State _ _ _ ob) = until halted smallstep (State (Just 0) empty empty "")
    smallstep (State (Just pc) rg mm ob)
      = case instruction of -- table of state changes for each small step
         Label _         ->  nochange
         NoOp            ->  nochange
         PrintR r        ->  updateout r
         MovR t r        ->  updatereg (t `insert` gr r)
         MovI t (I n)    ->  updatereg (t `insert` n)
         AddRR t r s     ->  updatereg (t `insert` (gr r + gr s))
         AddRI t r (I n) ->  updatereg (t `insert` (gr r + n))
         MulRR t r s     ->  updatereg (t `insert` (gr r * gr s))
         MulRI t r (I n) ->  updatereg (t `insert` (gr r * n))
         NegR t r        ->  updatereg (t `insert` (negate (gr r)))
         Halt            ->  updatepc Nothing
         JumpL l         ->  updatepc (Just (gl l))
         JumpR r         ->  updatepc (Just (gr r)) 
         BeqRR l r s     ->  jumpIf l (gr r == gr s)
         BeqRI l r (I n) ->  jumpIf l (gr r == n)
         BneRR l r s     ->  jumpIf l (gr r /= gr s)
         BneRI l r (I n) ->  jumpIf l (gr r /= n)
         BltRR l r s     ->  jumpIf l (gr r < gr s)
         BltRI l r (I n) ->  jumpIf l (gr r < n)
         BgeRR l r s     ->  jumpIf l (gr r >= gr s)
         BgeRI l r (I n) ->  jumpIf l (gr r >= n)
         MovL t l        ->  updatereg (t `insert` gl l)
         LoadR t r       ->  updatereg (t `insert` gm (gr r))
         LoadI t (I n)   ->  updatereg (t `insert` gm n)
         StoreR t r      ->  updatemem (gr t `insert` gr r)
         StoreI (I n) r  ->  updatemem (n `insert` gr r)
      where
        instruction = (A.!) js pc
        gr = getval rg -- value of register in current state
        gl = jumptable js -- line number of label l
        gm = getval mm -- value of location in main memory
        nxtpc = Just (pc + 1)
        updatereg f = State nxtpc (f rg) mm     ob -- update register, advancing program counter
        updateout r = State nxtpc rg     mm     (ob++"\n"++show (gr r)) -- update outputbuffer, advancing program counter
        updatemem f = State nxtpc rg     (f mm) ob -- update main memory, advancing program counter
        updatepc  p = State p     rg     mm     ob -- update program counter, with no other effect
        nochange    = updatepc nxtpc -- advance program counter, with no other effect
        jumpIf l g  = updatepc (if g then Just (gl l) else nxtpc) -- conditionally update program counter, with no other effect
        ------------------------------------

