module N.Parser where

import N.AbstractSyntax
import N.Scanner
import Control.Applicative -- to generate choices
import Control.Monad

newtype Parser a =  Parser {parse :: ([Token] -> [(a, [Token])])}
-- unlike Lexers, where failure is represented by Nothing, here failure is represented by an empty list of successes
-- in practice will only generate Parser Stmt, Parser Type & Parser Expr, the values need to parse N

instance Functor Parser where
  fmap g p = Parser (fmap g' . parse p)
    where
      g' (x, ts) = (g x, ts)

instance Applicative Parser where
  pure v   = Parser p
    where p ts = [(v, ts)]
  p <*> x = Parser (f .  parse p)
    where
      f []         = []
      f [(t, ts')] = parse (fmap t x) ts'

instance Monad Parser where
  x >>= p = Parser (f . parse x)
    where f []         = []
          f [(t, ts')] = parse (p t) ts'

instance Alternative Parser where
  empty   = Parser (const [])
  p <|> q = Parser (g . f)
    where f ts = (parse p ts, ts)
          g ([], ts) = parse q ts
          g (ps, _)  = ps

instance MonadPlus Parser where
  -- no definitions needed
instance MonadFail Parser where
  fail _ = mzero

instance Semigroup (Parser a) where
  (<>) = (<|>)
instance Monoid (Parser a) where
  mempty = empty

item :: Parser Token -- take one token from the input
item = Parser f
  where
    f []     = []
    f (x:xs) = [(x, xs)]

key :: Token -> a -> Parser a
key t e = do x <- item
             if x==t then return e else empty

pConstant :: Token -> a -> Parser a
pConstant t b = key t b

pNumeral :: Parser Expr
pNumeral = do NUM n <- item
              return (ValInt n)

pBrk :: Parser Expr
pBrk = do OPEN <- item
          x <- expression
          CLOSE <- item
          return x

pBinR :: Token -> (t1 -> t2 -> b) -> Parser t2 -> t1 -> Parser b
pBinR t b gc left = do f <- key t b
                       right <- gc
                       return (f left right)
                       
pUnary :: Token -> (t -> b) -> Parser t -> Parser b
pUnary t b gc = do f <- key t b
                   right <- gc
                   return (f right)

pVar :: Parser Expr
pVar = do VAR v <- item
          return (Ref v)

pIF :: Parser Stmt
pIF = do IF <- item
         g <- expression
         THEN <- item
         s <- statement
         ELSE <- item
         t <- statement
         FI <- item
         return (Ifte g s t)

pWHILE :: Parser Stmt
pWHILE = do WHILE <- item
            g <- expression
            DO <- item
            s <- statement
            OD <- item
            return (While g s)

pBLOCK :: Parser Stmt
pBLOCK = do BEGIN <- item
            VAR v <- item
            HASTYPE <- item
            t <- typeval
            IN <- item
            s <- statement
            END <- item
            return (Block v t s)

pASSIGN :: Parser Stmt
pASSIGN = do VAR v <- item
             ASSIGN <- item
             e <- expression
             return (v := e) 

clauses :: (Monad m, Monoid (m b)) => m b -> [b -> m b] -> m b
clauses e cs = do left <- e
                  foldMap ($left) (cs++[return])
---------------------------------------
-- Grammar for N

-- Expr
expression :: Parser Expr
expression = expr 0
  where
    expr :: (Eq t, Num t) => t -> Parser Expr
    expr 0 = clauses (expr 1) [pBinR EQUAL (:=:) (expr 0), pBinR LESS (:<:) (expr 0)]
    expr 1 = clauses (expr 2) [pBinR IMPLIES (:=>:) (expr 1), pBinR PLUS (:+:) (expr 1)]
    expr 2 = clauses (expr 3) [pBinR TIMES (:*:) (expr 2)]
    expr 3 = clauses (expr 4) [const (pUnary NEG Neg (expr 3))]
    expr 4 = pConstant FALSE ValFls <|> pConstant TRUE ValTru <|> pNumeral <|> pVar <|> pBrk

-- Type

typeval :: Parser Type
typeval = pConstant INTTYPE IntType <|> pConstant BOOLTYPE BoolType

-- Stmt

statement :: Parser Stmt
statement = stmt 0
  where
    stmt 0 = clauses (stmt 1) [pBinR SEQ (:>) (stmt 0)]
    stmt 1 = pConstant SKIP Skip <|> pUnary PRINT Print expression <|> pASSIGN <|> pIF <|> pWHILE <|> pBLOCK

parser_N :: [Token] -> Either String N
parser_N s = N ast
  where 
    ast = case parse statement s of
            [(p, [])]         -> Right p
            []                -> Left "Bad parse!"
            [(_, unconsumed)] -> Left ("Partial parse, leaving: " ++ show (take 10 unconsumed) ++ " ...")

scanparse :: String -> Either String N
scanparse = parser_N . scanner_N
