module N.Simplify (simplify) where
import N.AbstractSyntax hiding (pad, tab, ppStmt, ppT, ppE)

{-
   For typechecking the order of checking does not matter.
   That is not the case for simplification: subtrees of a node
   must be simplified before the node.  Consider (a fragment of) a function
   in the style of typechecking to simplify.  The fragment deletes addition
   of zeros on the right.
-}

simplifyE' :: Expr -> Expr
simplifyE' (a :+: ValInt 0) = simplifyE' a -- Zero is a right-unit of addition
simplifyE' (a :+: b)        = simplifyE' a :+: simplifyE' b -- otherwise simplify both subexpressions
simplifyE' a                = a -- nothing else changes

simplifyExample :: Expr
simplifyExample = (ValInt 1 :+: (ValInt 0 :+: ValInt 0))

{-
   To do this introduce a function to replace the constructor,
   and call function with already-simplified arguments.
   This ensures subtrees of a node are simplified before the node itself
   is considered.

   The basic pattern for a constructor C is:

   f (C a...z) = c a...z
     where
       SPECIAL CASES -- algebraic simplifications
       c a...z = C a...z  -- if not a special case, do nothing

-}
-- All functions assume type-correctness of input

simplify :: N -> N
simplify (N s) = N (simplifyStmt s)

simplifyStmt :: Stmt -> Stmt
-- Note we can leave all cases of "no change" to a single clause at the end
-- rules for print
simplifyStmt    (Print e) = print (simplifyExpr e)
  where print e = Print e
-- rules for assignment
simplifyStmt    (v := e) = v `ass` (simplifyExpr e)
  where v' `ass` e'@(Ref w) | v==w      = Skip
                            | otherwise = v `ass` e'
        v' `ass` e'         = v' := e'
-- rules for sequential composition
simplifyStmt (p :> q) = simplifyStmt p `seq` simplifyStmt q
  where Skip `seq` q    = q -- Left unit
        p    `seq` Skip = p -- Right unit
        p    `seq` q    = p :> q
-- rules for binary selection
simplifyStmt (Ifte e p q) = ifte (simplifyExpr e) (simplifyStmt p) (simplifyStmt q)
  where ifte ValTru p _ = p
        ifte ValFls _ q = q
        ifte e      p q | p==q      = p
                        | otherwise = Ifte e p q
-- rules for iteration
simplifyStmt (While e p) = while (simplifyExpr e) (simplifyStmt p)
  where while ValFls _ = Skip
        while e      p = While e p
-- rules for blocks
simplifyStmt (Block v t p) = block v t (simplifyStmt p)
  where block _ _ Skip = Skip
        -- other rules: if v is not free in p, replace Block v t p by p
        --              if v is only free variable in p, replace Block v t p by Skip
        --                 (first rule is a special case of this rule) 
        block v t p    = Block v t p
-- all others: no change
-- [Just Skip; but if we add new operators to the abstract syntax of statements the function would still work,
--  but not simplify the argument(s) of the new operator.]
simplifyStmt    e          = e

simplifyExpr :: Expr -> Expr
-- Note we can leave all cases of "no change" to a single clause at the end
-- rules for summation
simplifyExpr (a :+: b) = simplifyExpr a `sum` simplifyExpr b
  where ValInt m `sum` ValInt n = ValInt (m+n)
        a        `sum` ValInt 0 = a -- Right unit of addition
        ValInt 0 `sum` b        = b -- Left unit of addition
        a        `sum` b        = a :+: b 
-- rules for multiplication
simplifyExpr (a :*: b) = simplifyExpr a `mul` simplifyExpr b
  where ValInt m `mul` ValInt n = ValInt (m*n)
        _        `mul` ValInt 0 = ValInt 0 -- Right zero of multiplication
        ValInt 0 `mul` _        = ValInt 0 -- Left zero of multiplication
        a        `mul` ValInt 1 = a        -- Right unit of multiplication
        ValInt 1 `mul` b        = b        -- Left unit of multiplication
        a        `mul` b        = a :*: b
-- rules for negation
simplifyExpr (Neg e)            = neg (simplifyExpr e)
  where neg (ValInt n)          = ValInt (negate n)
        neg (Neg e)             = e -- self-inverse
        neg e                   = Neg e
-- rules for implication
simplifyExpr (a :=>: b) = simplifyExpr a `impl` simplifyExpr b
  where ValTru `impl` ValFls          = ValFls
        ValFls `impl` _               = ValTru
        _      `impl` ValTru          = ValTru
        (e :=>: ValFls) `impl` ValFls = e -- double negation
        a      `impl` b               = a :=>: b
simplifyExpr (a :<: b) = simplifyExpr a `lt` simplifyExpr b
  where ValInt m `lt` ValInt n | m < n     = ValTru
                               | otherwise = ValFls
        a `lt` b               = a :<: b
simplifyExpr (a :=: b) = simplifyExpr a `eq` simplifyExpr b
  where ValInt m `eq` ValInt n | m == n    = ValTru
                               | otherwise = ValFls
        a `eq` b               = a :=: b
-- all others: no change
-- [At the moment: just variables and constants;
--  if we added new operators to the abstract syntax of expressions the function would still work,
--  but not simplify the operator's argument(s).]
simplifyExpr e = e
