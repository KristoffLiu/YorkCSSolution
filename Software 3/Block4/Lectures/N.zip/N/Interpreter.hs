module N.Interpreter (interpret) where
import N.AbstractSyntax

-- assumes typecorrect & initialised-before-use

type Value = Either Int Bool -- a more complicated type structure for N would need a more complicated representation
type State = [(String, Value)]
type OutputBuffer = String

interpret :: N -> OutputBuffer
interpret (N p) = tail o
  where (_, o) = bigstep p []

bigstep :: Stmt ->       State -> (State, OutputBuffer)
bigstep    Skip          s      = (s, "")
bigstep    (Print e)     s      = (s, '\n':val)
  where val = either show show (eval e s)
bigstep    (v := e)      s      = ((v, (eval e s)):s, "")
bigstep    (p :> q)      s      = (t, op ++ oq)
  where
    (m, op) = bigstep p s
    (t, oq) = bigstep q m
bigstep    (Ifte e p q)  s      = bigstep (if b then p else q) s
  where Right b = eval e s
bigstep    w@(While e p) s      = bigstep (if b then p:>w else Skip) s
  where Right b = eval e s
bigstep    (Block _ _ p) s      = (tail m, op)
  where (m, op) = bigstep p s

eval :: Expr -> State -> Value
eval (ValInt n) _      = Left n
eval ValTru     _      = Right True
eval ValFls     _      = Right False
eval (Ref v)    s      = w
  where Just w = lookup v s -- assumes initialisation before use
eval (a :+: b)  s      = Left (av + bv)
  where Left av = eval a s
        Left bv = eval b s
eval (a :*: b)  s      = Left (av * bv)
  where Left av = eval a s
        Left bv = eval b s
eval (Neg a)    s      = Left (negate av)
  where Left av = eval a s
eval (a :=>: b) s      = Right (av <= bv) -- arises from ordering on Bool
  where Right av = eval a s
        Right bv = eval b s
eval (a :<: b)  s      = Right (av < bv)
  where Left av = eval a s
        Left bv = eval b s
eval (a :=: b)  s      = Right (av == bv)
  where Left av = eval a s
        Left bv = eval b s
