module N.StaticCheck (typecheck, checkInitB4Use) where
import N.AbstractSyntax
import Data.Set

-- Typechecking as root-to-leaf processing.
-- Need one function per syntax class (but, as there are no type expressions in Mini we don't need one for Type).
-- Typechecking needs an environment of declared variables and their types.  For simplicity we will make this a list of pairs:

type Env = [(Var, Type)]

-- this has the advantage that lookup always returns the value associated with the first occurence of key, making updating simpler.

-- An error message is generated for every leaf, if no error then the message is the empty string.

no_error :: String
no_error = ""

checktype :: Type -> Type -> String
checktype exp fnd
  | exp == fnd = no_error
  | otherwise  = "Type "++show exp++" expected, but type "++show fnd++" found\n"

checkvar :: Env -> Var -> (Type -> String) -> String 
checkvar g v f = case lookup v g of
                   Nothing -> "No such variable: `" ++ v ++ "'\n"
                   Just s  -> f s

typecheck :: N  -> String
typecheck (N source) = typecheckStmt [] source

typecheckStmt :: Env -> Stmt -> String
typecheckStmt g = tcs
  where
    tcs Skip         = no_error
    tcs (Print e)    = typecheckExpr g IntType e
    tcs (v := e)  = checkvar g v (\s -> typecheckExpr g s e)
    tcs (p :> q)  = tcs p ++ tcs q
    tcs (Ifte e p q) = typecheckExpr g BoolType e ++ tcs p ++ tcs q
    tcs (While e p)  = typecheckExpr g BoolType e ++ tcs p
    tcs (Block v t s) = typecheckStmt ((v,t):g) s

typecheckExpr :: Env -> Type -> Expr -> String
typecheckExpr g t = tce
  where
    tce (Ref v)    = checkvar g v (checktype t)
    tce (ValInt _) = checktype t IntType
    tce ValTru     = checktype t BoolType
    tce ValFls     = checktype t BoolType
    tce (a :+: b)  = checktype t IntType ++ tcei a ++ tcei b
      where tcei = typecheckExpr g IntType
    tce (a :*: b)  = checktype t IntType ++ tcei a ++ tcei b
      where tcei = typecheckExpr g IntType
    tce (Neg e)    = checktype t IntType ++ typecheckExpr g IntType e
    tce (a :=>: b) = checktype t BoolType ++ tceb a ++ tceb b
      where tceb = typecheckExpr g BoolType
    tce (a :<: b)  = checktype t BoolType ++ tcei a ++ tcei b
      where tcei = typecheckExpr g IntType
    tce (a :=: b)  = checktype t BoolType ++ tcei a ++ tcei b
      where tcei = typecheckExpr g IntType
{-
The type checker does not catch uses of a variables that have not been
assigned a value.  An example is:

There are three ways of fixing this.
1. Change the abstract syntax so that declarations include an explicit initialisation
2. Write a function that checks initialisation-before-use
3. Use default initialisations

Each has advantages & disadvantages.  My preference is for 1, then 2, then 3.

Exercise: Why would that be my preference?

Exercise: Take a renamed copy of the abstract syntax, make modification 1, and re-implement the typechecker for the new language.

Exercise: Write a function to check for initialisation before use.
  [Hint: Use a set of variable names which are initialised.
   Hint: Don't forget to delete the newly declared name when entering a new block.]

Possible exam question: Add input statement, and find outputs that depend on an input. [Some tricky issues here -- needs more thought.]
-}

-- a solution to checking for initialisation before use
checkInitB4Use :: N -> String
checkInitB4Use (N s) = ci empty s
  where
    ci _ Skip            = no_error
    ci s (Print e)       = cv s e
    ci s (v := e)        = cv s e
    ci s ((v := e) :> p) = cv s e ++ ci (insert v s) p -- an assignment records variable as initialised
    ci s (p :> q)        = ci s p ++ ci s q
    ci s (Ifte e p q)    = cv s e ++ ci s p ++ ci s q
    ci s (While e p)     = cv s e ++ ci s p
    ci s (Block v _ p)   = ci (delete v s) p -- v is no longer initialised
    
    cv _ (ValInt _) = no_error
    cv _ ValTru     = no_error
    cv _ ValFls     = no_error
    cv s (Ref v)    | v `member` s = no_error
                    | otherwise    = "Variable `" ++ v ++ "' not initialised\n"
    cv s (a :+: b)  = cv s a ++ cv s b
    cv s (a :*: b)  = cv s a ++ cv s b
    cv s (Neg a)    = cv s a
    cv s (a :=>: b) = cv s a ++ cv s b
    cv s (a :<: b)  = cv s a ++ cv s b
    cv s (a :=: b)  = cv s a ++ cv s b

{-
Further exercise: discuss merits of checking initialisation-before-use
                  before or after simplification.
-}
