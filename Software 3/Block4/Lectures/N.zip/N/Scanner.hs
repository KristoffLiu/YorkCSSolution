module N.Scanner where

{-
  Lexer a t accepts strings over alphabet "a" and
  returns (1) either Just token if it matches, or else Nothing,
          (2) unprocessed string

  Lexers described as token function & regexp

  As much of this is done with newtype, it is typesafe without costing anything at runtime.

  The description relies as on the mathamatical underpinnings:
  * RegExps are a special case of Lexers
  * RegExps are summative and product monoids;
  * Lexers are functors
  * Lexers are summative monoids (we do not need product monoids of general lexers)
-}

newtype Lexer a t = Lexer {(|>) :: [a] -> (Maybe t, [a])}

instance Functor (Lexer a) where -- we will exclusively describe general lexers as liftings of lexers based on RegExps
  fmap f l = Lexer h
    where h xs = (maybe Nothing (Just . f) m, s')
            where (m, s') = l |> xs

instance Semigroup (Lexer a t) where -- alternation between lexers; prioritised to the left
  p <> q = Lexer l
    where l s = maybe (q|>s) (const split) m
            where split@(m, _) = p|>s
instance Monoid (Lexer a t) where
  mempty = Lexer (\s -> (Nothing, s)) -- 

newtype RegExp a = RegExp (Lexer a [a]) -- specialised lexer

regexp :: ([a] -> (Maybe [a], [a])) -> RegExp a -- a smart constructor
regexp = RegExp . Lexer

(>$) :: RegExp a -> ([a] -> b) -> Lexer a b -- lift a RegExp to a Lexer
(RegExp re) >$ tf = tf <$> re

-- monoidal structure of RegExps

newtype RegExpAlt a = RegExpAlt (RegExp a)
newtype RegExpSeq a = RegExpSeq (RegExp a)

instance Semigroup (RegExpAlt a) where -- summation semigroup, inherited from alternation of general lexers
  RegExpAlt (RegExp p) <> RegExpAlt (RegExp q) = RegExpAlt (RegExp (p <> q))
instance Monoid (RegExpAlt a) where -- summation monoid, inherited from alternation monoid of general lexers
  mempty = RegExpAlt (RegExp mempty) -- empty language EXERCISE complete RHS
  
instance Semigroup (RegExpSeq a) where -- product semigroup, from first principals
  RegExpSeq (RegExp p) <> RegExpSeq (RegExp q) = RegExpSeq (regexp r)
    where r s | (Just toka, Just tokb) <- (m, n) = (Just (toka ++ tokb), v)
              | otherwise                        = (Nothing, s)
            where (m, u) = p |> s
                  (n, v) = q |> u

nil :: RegExp a -- language containing only the empty string
nil = regexp (\s -> (Just [], s)) -- EXERCISE complete RHS

instance Monoid (RegExpSeq a) where -- a product monoid, from first principals
  mempty = RegExpSeq nil -- language of the empty string -- EXERCISE complete RHS

foldMapRE :: (Foldable f, Monoid b) => (a -> b) -> (b -> a) -> f a -> a -- utility to wrap, fold as appropriate, & unwrap
foldMapRE wrap unwrap = unwrap . foldMap wrap -- it is a shame that Haskell 98 does not allow calculation of unwrap!

alts :: (Foldable f) => f (RegExp a) -> RegExp a
alts = foldMapRE RegExpAlt (\(RegExpAlt r)->r)

seqs :: (Foldable f) => f (RegExp a) -> RegExp a
seqs = foldMapRE RegExpSeq (\(RegExpSeq r)->r)

star :: RegExp a -> RegExp a -- iterate p zero or more times
star p = alts[(seqs[p, star p]), nil] -- EXERCISE complete RHS
            
-- useful general RegExp generators
symb :: Eq a => a -> RegExp a -- language containing just "x"
symb x = regexp r
  where r (y:t) | x==y = (Just [y], t)
        r s            = (Nothing,  s)

anybut :: Eq a => a -> RegExp a -- language all "y", for y in a\{x}
anybut x = regexp r  -- EXERCISE complete RHS
  where r (y:t) | x/=y = (Just [y], t)
        r s            = (Nothing,  s)

anyA :: RegExp a -- accepts any single character
anyA = regexp r  -- EXERCISE complete RHS
  where r (y:t) = (Just [y], t)
        r []    = (Nothing, [])
----------------------------
-- Derived combinators

plus ::  Eq a => RegExp a -> RegExp a -- iterate p one or more times
plus p = seqs[p, star p] -- EXERCISE complete RHS

anyof :: (Foldable f, Functor f, Eq a) => f a -> RegExp a
anyof = alts . fmap symb -- EXERCISE complete RHS

word :: (Foldable f, Functor f, Eq a) => f a -> RegExp a
word = seqs . fmap symb -- EXERCISE complete RHS

emptyLang :: RegExp a
emptyLang = alts []
---------------------------
-- a Lexical scanner
scanner :: (Eq a, Show a) => RegExp a -> Lexer a t -> [a] -> [t]
scanner (RegExp w) b = swb
  where
    swb s | s' == []  = [] -- nothing left to process
          | otherwise = maybe errorReport (:swb t) m
      where
        (_, s') = w |> s
        (m, t)  = b |> s'
        errorReport = error ("\n\tLexing error detected at: "++show(take 8 t)) -- show 8 symbols, starting at error

-- ========================
-- Elements for N

comment, blank, whitespace :: RegExp Char
comment = seqs [symb '{', star (anybut '}'), symb '}']
blank = anyof " \n\t"
whitespace = plus (alts[blank, comment])

data Token = SKIP | PRINT | ASSIGN | SEQ | IF | THEN | ELSE | FI | WHILE | DO | OD | BEGIN | IN | END
           | OPEN | CLOSE | VAR String | NUM Int | TRUE | FALSE | PLUS | TIMES | NEG | IMPLIES | LESS | EQUAL
           | INTTYPE | BOOLTYPE | HASTYPE
           deriving (Eq, Show)

kwd :: Lexer Char Token
kwd = foldMap (\(s, t)-> word s >$ const t) kwdrep
  where
    kwdrep = [ ("Skip",    SKIP)
             , ("Print",   PRINT)
             , (":=",      ASSIGN)
             , (";",       SEQ)
             , ("IF",      IF)
             , ("THEN",    THEN)
             , ("ELSE",    ELSE)
             , ("FI",      FI)
             , ("WHILE",   WHILE)
             , ("DO",      DO)
             , ("OD",      OD)
             , ("BEGIN",   BEGIN)
             , ("IN",      IN)
             , ("END",     END)
             , ("TRUE",    TRUE)
             , ("FALSE",   FALSE)
             , ("+",       PLUS)
             , ("*",       TIMES)
             , ("-",       NEG)
             , ("=>",      IMPLIES)
             , ("<",       LESS)
             , ("=",       EQUAL)
             , ("(",       OPEN)
             , (")",       CLOSE)
             , ("Integer", INTTYPE)
             , ("Boolean", BOOLTYPE)
             , (":",       HASTYPE)]


variable :: Lexer Char Token
variable = plus (anyof "abcdefghijklmnopqrstuvwxyz") >$ VAR

numeral :: Lexer Char Token
numeral = plus (anyof "0123456789") >$ (NUM . read)

scanner_N :: String -> [Token]
scanner_N = scanner whitespace (kwd <> variable <> numeral)
