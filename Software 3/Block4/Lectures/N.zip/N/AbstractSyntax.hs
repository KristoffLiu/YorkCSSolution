module N.AbstractSyntax where
  
type Var = String -- Alias for variable names

infixr 4 :> -- sequential composition
infix  5 := -- assignment
infix  6 :<: -- less than
infix  6 :=: -- equality
infixr 7 :+: -- summation
infixr 8 :*: -- multiplication
infixr 8 :=>: -- implication

newtype N = N Stmt deriving (Show)

-- abstract syntax of statements
data Stmt = Skip                 -- null statement
          | Print Expr           -- Print value of Integer expression
          | String := Expr    -- Assignment
          | Stmt :> Stmt      -- sequential composition
          | Ifte Expr Stmt Stmt  -- if then else
          | While Expr Stmt      -- while do
          | Block Var Type Stmt  -- declaration
          deriving (Eq, Show)

-- abstract syntax of types (a trivial type system)
data Type = IntType | BoolType deriving (Eq, Show)

-- abstract syntax of expressions
data Expr = Ref Var    -- variable name
          | ValInt Int -- integer value
          | ValTru     -- Boolean value
          | ValFls     -- Boolean value
          | Expr :+: Expr -- add
          | Expr :*: Expr -- times
          | Neg Expr        -- unary negation
          | Expr :=>: Expr -- implication
          | Expr :=: Expr -- equality
          | Expr :<: Expr -- inequality
          deriving (Eq, Show)


pad :: Int -> String -- n spaces
pad n = '\n' : replicate n ' '

tab :: Int
tab = 2

-- a pretty printer
prettyprint :: N -> String
prettyprint (N s) = ppStmt s

ppStmt :: Stmt -> String
ppStmt = (flip (++) "\n") . tail . pp 0
  where
    pp n Skip = pad n ++ "Skip"
    pp n (Print e) = pad n ++ "PRINT " ++ ppE e
    pp n (v := e) = pad n ++ v ++ " := " ++ ppE e
    pp n (p :> q) = pp n p ++ ";" ++ pp n q
    pp n (Ifte e p q) =    padn   ++ "IF"
                        ++ pad nt ++   ppE e
                        ++ padn   ++ "THEN"
                        ++ ppnt        p
                        ++ padn   ++ "ELSE"
                        ++ ppnt        q
                        ++ padn   ++ "FI"
      where padn  = pad n
            nt    = n + tab 
            ppnt  = pp nt
    pp n (While e p) =    padn ++ "WHILE"
                       ++ pad nt ++  ppE e
                       ++ padn ++ "DO"
                       ++            pp nt p
                       ++ padn ++ "OD"
      where padn = pad n
            nt = n + tab
    pp n (Block v t p) =    padn ++ "BEGIN"
                         ++ pad nt ++ v ++ " : " ++ ppT t
                         ++ padn ++ "IN" ++ pp nt p
                         ++ padn ++ "END"
      where padn = pad n
            nt   = n + tab
    
ppT :: Type -> String
ppT IntType = "Integer"
ppT BoolType = "Boolean"

binop :: Expr -> Expr -> String -> String
binop a b s = "(" ++ ppE a ++ " " ++ s ++ " " ++ ppE b ++ ")"

ppE :: Expr      -> String
ppE    (Ref v)    = v
ppE    (ValInt i) = show i
ppE    ValTru     = "TRUE"
ppE    ValFls     = "FALSE"
ppE    (a :+: b)  = binop a b "+"
ppE    (a :*: b)  = binop a b "*"
ppE    (Neg a)    = " -" ++ ppE a
ppE    (a :=>: b) = binop a b "=>"
ppE    (a :<: b)  = binop a b "<"
ppE    (a :=: b)  = binop a b "="

