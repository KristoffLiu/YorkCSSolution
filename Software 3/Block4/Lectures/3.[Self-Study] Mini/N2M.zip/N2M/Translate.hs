module N2M.Translate (translate) where
import M.AbstractSyntax
import N.AbstractSyntax
import Data.Set -- for recording variables in existence at 

{-
When generating M from N we will need fresh variable and label names.
There are several ways to do this: monads are an obvious way and used here.
Using monads means that the identity of the next fresh variable is implicitly
threaded through the computation.
-}

import Control.Monad.State.Lazy

type Env = Set String  -- value records variables in existence at current point of compilation
type Fresh a = State Int a -- value carries counter used to generate next fresh name, implicitly passed between Fresh values; provides an output of type a.

fresh :: Fresh Int -- increment value in state
fresh = do n <- get -- get from state
           put (n+1) -- store increment
           return n -- return current value

-- special values
sTop = R "_StackTop"
tru = I 1  -- True represented by one
fls = I 0  -- False represented by zero

translate :: N   -> M
translate   (N s) = mkM ([MovI sTop (memsize 8)] -- set stack point to top of memory
                         ++ evalState (translateS empty s) 0 -- compilation of statement, first fresh label is 0
                         ++ [Halt]) -- stop computation
  where memsize bits = I (round (2**bits))
  
translateS :: Env -> Stmt -> Fresh [Instr]
translateS    env  = trS
  where
    trS    Skip                  = do return []
    trS    (Print e)             = do (a, r) <- translateE env e
                                      return (a ++ [PrintR r])
    trS    (v := Ref w)          = do return [MovR (R v) (R w)]
    trS    (v := ValInt n)       = do return [MovI (R v) (I n)]
    trS    (v := ValTru)         = do return [MovI (R v) tru]
    trS    (v := ValFls)         = do return [MovI (R v) fls]
    trS    (v := ValInt n :+: e) = do (a, r) <- translateE env e
                                      return (a ++ [AddRI (R v) r (I n)])
    trS    (v := e :+: ValInt n) = do (a, r) <- translateE env e
                                      return (a ++ [AddRI (R v) r (I n)])
    trS    (v := e :+: f)        = do (a, r) <- translateE env e
                                      (b, s) <- translateE env f
                                      return (a ++ b ++ [AddRR (R v) r s])
    trS    (v := ValInt n :*: e) = do (a, t) <- translateE env e
                                      return (a ++ [MulRI (R v) t (I n)])
    trS    (v := e :*: ValInt n) = do (a, t) <- translateE env e
                                      return (a ++ [MulRI (R v) t (I n)])
    trS    (v := e :*: f)        = do (a, t) <- translateE env e
                                      (b, u) <- translateE env f
                                      return (a ++ b ++ [MulRR (R v) t u])
    trS    (v := Neg e)          = do (a, t) <- translateE env e
                                      return (a ++ [NegR (R v) t])
    trS    (v := e :=>: f)       = do (a, t) <- translateE env e
                                      (b, u) <- translateE env e
                                      new <- fresh
                                      let isTru = L ("IS_TRU-" ++ show new)
                                      let end = L ("END-" ++ show new)
                                      return [BeqRI isTru t fls, BneRI isTru u fls, MovI (R v) fls, JumpL end, Label isTru, MovI (R v) tru, Label end]
    trS    (v := e :=: f)        = do (a, t) <- translateE env e
                                      (b, u) <- translateE env e
                                      new <- fresh
                                      let isTru = L ("IS_TRU-" ++ show new)
                                      let end = L ("END-" ++ show new)
                                      return [BeqRR isTru t u, MovI (R v) fls, JumpL end, MovI (R v) tru, Label end]
    trS    (v := e :<: f)        = do (a, t) <- translateE env e
                                      (b, u) <- translateE env e
                                      new <- fresh
                                      let isTru = L ("IS_TRU-" ++ show new)
                                      let end = L ("END-" ++ show new)
                                      return [BltRR isTru t u, MovI (R v) fls, JumpL end, MovI (R v) tru, Label end]
    trS    (p :> q)              = do a <- trS p
                                      b <- trS q
                                      return (a ++ b)
    trS    (Ifte g p q)          = do new <- fresh
                                      let els = L ("ELSE-" ++ show new)
                                      let end = L ("FI-" ++ show new)
                                      a <- translateBN env g els
                                      b <- trS p
                                      c <- trS q
                                      return (a ++ b ++ [JumpL end, Label els] ++ c ++ [Label end])
    trS    (While g p)           = do new <- fresh -- bottom-test stragtegy
                                      let top = L ("TOP-" ++ show new)
                                      let tst = L ("TEST-" ++ show new)
                                      a <- trS p
                                      b <- translateBP env g top
                                      return ([JumpL tst, Label top] ++ a ++ [Label tst] ++ b)
    trS    (Block v _ s)         | v `member` env = do a <- trS s
                                                       return ([     AddRI sTop sTop (I (negate 1)) -- together implements push v,
                                                               ,     StoreR sTop (R v)]             -- to save outermost value
                                                                ++   a
                                                                ++ [ LoadR (R v) sTop               -- together implements pop v,
                                                                   , AddRI sTop sTop (I 1)])        -- to restore outermost value
                                 | otherwise      = do a <- translateS (v `insert` env) s
                                                       return a

translateE :: Env -> Expr -> Fresh ([Instr], R)
translateE _   (Ref v)  = do return ([], R v)
translateE env e        = do t <- fresh
                             let vt = 'v':show t
                             a <- translateS env (vt := e)
                             return (a, R vt)
                        
translateBP, translateBN
            :: Env -> Expr ->    L -> Fresh [Instr]
translateBP    _      ValFls     l  = do return []
translateBP    _      ValTru     l  = do return [JumpL l]
translateBP    _      (Ref v)    l  = do return [BneRI l (R v) fls]
translateBP    env    (g :=>: h) l  = do a <- translateBN env g l
                                         b <- translateBP env h l
                                         return (a ++ b)
translateBP    env    (e :=: f)  l  = do (a, t) <- translateE env e
                                         (b, u) <- translateE env f
                                         return (a ++ b ++ [BeqRR l t u])
translateBP    env    (e :<: f)  l  = do (a, t) <- translateE env e
                                         (b, u) <- translateE env f
                                         return (a ++ b ++ [BltRR l t u])

translateBN    _      ValFls     l  = do return [JumpL l]
translateBN    _      ValTru     l  = do return []
translateBN    _      (Ref v)    l  = do return [BeqRI l (R v) fls] 
translateBN    env    (g :=>: h) l  = do new <- fresh
                                         let end = L ('L':show new)
                                         a <- translateBN env g end
                                         b <- translateBN env h l
                                         return (a ++ b ++ [Label end]) 
translateBN    env    (e :=: f)  l  = do (a, t) <- translateE env e
                                         (b, u) <- translateE env f
                                         return (a ++ b ++ [BneRR l t u])
translateBN    env    (e :<: f)  l  = do (a, t) <- translateE env e
                                         (b, u) <- translateE env f
                                         return (a ++ b ++ [BgeRR l t u])
